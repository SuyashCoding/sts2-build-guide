import type { Metadata } from 'next'
import { Kreon } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const kreon = Kreon({ subsets: ['latin'], weight: ['300', '400', '500', '600', '700'] });

export const metadata: Metadata = {
  title: 'Slay the Spire 2 - Character Guides',
  description: 'Comprehensive build guides and documentation for all Slay the Spire 2 characters',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${kreon.className} antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
